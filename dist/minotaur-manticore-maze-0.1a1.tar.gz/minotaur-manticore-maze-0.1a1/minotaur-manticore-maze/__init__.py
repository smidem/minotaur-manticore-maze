from progress import Progress

print('\u2680','\u2681','\u2682','\u2683','\u2684')
