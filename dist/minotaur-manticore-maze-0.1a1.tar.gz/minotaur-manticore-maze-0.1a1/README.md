This is a text-based game where you navigate a maze and battle minotaurs and
manticores. Along the way you will find interesting items and hidden areas that
may improve your chances of success.

I hope you enjoy it! Please let me know if you have any criticisms or feedback. 
